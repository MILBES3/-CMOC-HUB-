import {env} from 'cloudflare:workers';
import {defaultSettings,normalizeSettings,type SiteSettings} from '@/app/site-settings';
export function db(){if(!env.DB)throw new Error('Database unavailable');return env.DB}
export async function readSettings():Promise<SiteSettings>{
 const row=await db().prepare('SELECT value FROM hub_settings WHERE key=?').bind('dashboard').first<{value:string}>();
 if(!row)return defaultSettings;
 const stored=JSON.parse(row.value) as Partial<SiteSettings>;
 return normalizeSettings(stored);
}
export function sameOrigin(request:Request){
 const origin=request.headers.get('origin');if(!origin)return true;
 try{
  const originUrl=new URL(origin);const requestUrl=new URL(request.url);
  const forwardedHost=request.headers.get('x-forwarded-host')?.split(',')[0]?.trim();
  const host=forwardedHost||request.headers.get('host')||requestUrl.host;
  const protocol=(request.headers.get('x-forwarded-proto')?.split(',')[0]?.trim()||requestUrl.protocol.replace(':',''))+':';
  return originUrl.host===host&&originUrl.protocol===protocol;
 }catch{return false}
}
