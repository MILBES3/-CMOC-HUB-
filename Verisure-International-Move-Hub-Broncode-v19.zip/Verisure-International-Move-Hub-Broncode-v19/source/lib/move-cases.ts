import {z} from 'zod';

export const countryCodes=['AR','BE','BR','CL','DK','FI','FR','DE','IE','IT','MX','NL','NO','PE','PT','ES','SE','GB'] as const;
export const countries:Record<string,string>={AR:'Argentinië',BR:'Brazilië',CL:'Chili',MX:'Mexico',PE:'Peru',BE:'België',DK:'Denemarken',FI:'Finland',FR:'Frankrijk',DE:'Duitsland',IE:'Ierland',IT:'Italië',NL:'Nederland',NO:'Noorwegen',PT:'Portugal',ES:'Spanje',SE:'Zweden',GB:'Verenigd Koninkrijk'};
export type CountryCode=typeof countryCodes[number];
export const latinAmericaCountries=new Set<string>(['AR','BR','CL','MX','PE']);
export const pilotCountries=new Set(['BE','DE','NL']);
export type CountryResult='CANCEL'|'PROGRESS'|'SALE';
export const resultStatus:Record<CountryResult,string>={CANCEL:'NO_SALE',PROGRESS:'IN_PROGRESS',SALE:'SALE_REALIZED'};
export const resultFromStatus=(status:string):CountryResult=>status==='NO_SALE'?'CANCEL':status==='SALE_REALIZED'?'SALE':'PROGRESS';
function amsterdamDate(value:Date){const parts=Object.fromEntries(new Intl.DateTimeFormat('en-CA',{timeZone:'Europe/Amsterdam',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(value).map(p=>[p.type,p.value]));return parts.year+'-'+parts.month+'-'+parts.day}
export const today=()=>amsterdamDate(new Date());
export function dateInput(value:string|null|undefined){return value&&Number.isFinite(Date.parse(value))?value.slice(0,10):''}
export const isPilot=(row:{origin_country:string;destination_country:string})=>row.origin_country!==row.destination_country&&pilotCountries.has(row.destination_country);
export const isTransferred=(row:{consent:string;sent_at:string|null})=>row.consent==='Yes'&&!!row.sent_at;
export const isSale=(row:{status:string})=>row.status==='SALE_REALIZED';
const validDate=z.string().date();
const timestamp=z.string().datetime({offset:true});
const nullableDate=z.union([validDate,timestamp,z.literal(''),z.null()]).optional();
const yes=z.enum(['Yes','No','Pending']);
export const caseSchema=z.object({
 originCountry:z.enum(countryCodes),destinationCountry:z.enum(countryCodes),
 customerName:z.string().trim().min(2,'Vul een klantnaam van minimaal 2 tekens in.').max(160),
 phone:z.string().trim().max(80).default('').refine(v=>!v||(/^\+?[\d\s().-]+$/.test(v)&&v.replace(/\D/g,'').length>=7&&v.replace(/\D/g,'').length<=15),'Vul een geldig telefoonnummer in.'),
 email:z.union([z.literal(''),z.string().trim().email('Vul een geldig e-mailadres in.')]).default(''),
 nlOwner:z.string().max(120).default(''),receivingOwner:z.string().max(120).default(''),
 status:z.enum(['IN_PROGRESS','LEAD_CREATED','CONSENT_RECEIVED','SENT_TO_COUNTRY','CUSTOMER_CONTACTED','CUSTOMER_UNREACHABLE','INTEREST_CONFIRMED','APPOINTMENT_PLANNED','SALE_REALIZED','NO_SALE']).default('LEAD_CREATED'),
 consent:yes.default('Pending'),consentAt:nullableDate,consentVersion:z.string().max(50).nullable().optional(),
 moveDate:nullableDate,preferredContactAt:nullableDate,sentAt:nullableDate,firstContactAt:nullableDate,
 contactOutcome:z.string().max(120).nullable().optional(),reached:yes.default('Pending'),interested:yes.default('Pending'),
 appointmentAt:nullableDate,installed:yes.default('No'),installedAt:nullableDate,estimatedRevenue:z.number().finite().min(0).nullable().optional(),
 noSaleReason:z.string().max(400).nullable().optional(),description:z.string().max(2000).nullable().optional(),retentionUntil:nullableDate,
 expectedUpdatedAt:z.string().optional()
}).superRefine((value,ctx)=>{
 const issue=(path:string,message:string)=>ctx.addIssue({code:z.ZodIssueCode.custom,path:[path],message});
 if(value.originCountry===value.destinationCountry)issue('destinationCountry','Vertrekland en bestemmingsland moeten verschillend zijn.');
 if(value.sentAt&&value.consent!=='Yes')issue('consent','Registreer toestemming voordat je een lead doorstuurt.');
 if(value.sentAt&&!value.phone&&!value.email)issue('phone','Vul een telefoonnummer of e-mailadres in voordat je doorstuurt.');
 if(value.sentAt&&!value.moveDate)issue('moveDate','Vul de verhuisdatum in voordat je doorstuurt.');
 if(value.sentAt&&dateInput(value.sentAt)>today())issue('sentAt','De doorstuurdatum mag niet in de toekomst liggen.');
 if(value.firstContactAt&&value.sentAt&&Date.parse(value.firstContactAt)<Date.parse(value.sentAt))issue('firstContactAt','De eerste opvolging kan niet vóór de overdracht liggen.');
 if(value.status==='SALE_REALIZED'&&(!value.sentAt||value.consent!=='Yes'))issue('status','Een SALE vereist toestemming en een overgedragen lead.');
});
export type CaseInput=z.infer<typeof caseSchema>;
export function normalizeCase(data:CaseInput,existing?:{sent_at?:string|null;consent_at?:string|null;first_contact_at?:string|null;status?:string},now=new Date().toISOString()):CaseInput{
 const next={...data};
 // A date entered today becomes a real handover at save time. Backdated dates keep their known precision.
 if(next.sentAt&&dateInput(next.sentAt)===dateInput(existing?.sent_at))next.sentAt=existing?.sent_at;
 else if(next.sentAt===today())next.sentAt=now;
 if(next.consent==='Yes')next.consentAt=existing?.consent_at||now;
 if(['LEAD_CREATED','CONSENT_RECEIVED','SENT_TO_COUNTRY'].includes(next.status))next.status=next.sentAt?'SENT_TO_COUNTRY':next.consent==='Yes'?'CONSENT_RECEIVED':'LEAD_CREATED';
 if(existing?.first_contact_at)next.firstContactAt=existing.first_contact_at;
 next.installed=next.status==='SALE_REALIZED'?'Yes':'No';
 if(next.status==='SALE_REALIZED'){next.reached='Yes';next.interested='Yes'}
 return next;
}
function endOfAmsterdamDate(value:string){
 const date=dateInput(value);if(!date)return null;
 const [year,month,day]=date.split('-').map(Number);
 const noon=new Date(Date.UTC(year,month-1,day,12));
 const parts=Object.fromEntries(new Intl.DateTimeFormat('en-CA',{timeZone:'Europe/Amsterdam',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'}).formatToParts(noon).filter(p=>p.type!=='literal').map(p=>[p.type,p.value]));
 const offset=Date.UTC(Number(parts.year),Number(parts.month)-1,Number(parts.day),Number(parts.hour),Number(parts.minute),Number(parts.second))-noon.getTime();
 return new Date(Date.UTC(year,month-1,day,23,59,59,999)-offset).toISOString();
}
export function deadlineFor(createdAt:string,preferredContactAt?:string|null){return preferredContactAt?endOfAmsterdamDate(preferredContactAt)??new Date(Date.parse(createdAt)+86400000).toISOString():new Date(Date.parse(createdAt)+86400000).toISOString()}
export function countdown(row:{created_at:string;preferred_contact_at?:string|null;status:string},now=Date.now()){
 if(['SALE_REALIZED','NO_SALE'].includes(row.status))return {state:'closed' as const,seconds:0};
 const preferred=dateInput(row.preferred_contact_at);
 const deadline=Date.parse(deadlineFor(row.created_at,row.preferred_contact_at));
 if(!Number.isFinite(deadline))return {state:'unknown' as const,seconds:0};
 const seconds=Math.max(0,Math.ceil((deadline-now)/1000));
 const nowDate=amsterdamDate(new Date(now));
 return {state:preferred&&preferred===nowDate?'today' as const:seconds>0?'running' as const:'overdue' as const,seconds};
}
export function sla(row:{created_at:string;preferred_contact_at?:string|null;status:string},now=Date.now()){
 const state=countdown(row,now).state;
 return state==='closed'?'Afgesloten':state==='unknown'?'Tijdstip onbekend':state==='overdue'?'Verlopen':'Lopend';
}
