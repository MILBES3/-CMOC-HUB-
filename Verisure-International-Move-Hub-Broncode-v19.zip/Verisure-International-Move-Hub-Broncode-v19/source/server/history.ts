import records from './historical-data.json';
import {db} from './settings';
export async function readHistory(){const edits=await db().prepare('SELECT id,value FROM historical_edits').all<{id:number;value:string}>();const byId=new Map(edits.results.map(r=>[r.id,JSON.parse(r.value)]));return records.map((r,id)=>({...r,destinationCountry:'',...byId.get(id),id}))}
