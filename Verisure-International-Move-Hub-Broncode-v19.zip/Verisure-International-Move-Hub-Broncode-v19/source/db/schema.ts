import { integer, real, sqliteTable, text } from 'drizzle-orm/sqlite-core';

export const cases = sqliteTable('cases', {
  id: text('id').primaryKey(), originCountry: text('origin_country').notNull().default('NL'), destinationCountry: text('destination_country').notNull(),
  customerName: text('customer_name').notNull(), phone: text('phone').notNull().default(''), email: text('email').notNull().default(''),
  nlOwner: text('nl_owner').notNull().default(''), receivingOwner: text('receiving_owner').notNull().default(''), status: text('status').notNull().default('LEAD_CREATED'),
  consent: text('consent').notNull().default('Pending'), consentAt: text('consent_at'), consentVersion: text('consent_version'),
  moveDate: text('move_date'), preferredContactAt: text('preferred_contact_at'), createdAt: text('created_at').notNull(), sentAt: text('sent_at'),
  slaDeadline: text('sla_deadline'), firstContactAt: text('first_contact_at'), contactOutcome: text('contact_outcome'),
  reached: text('reached').notNull().default('Pending'), interested: text('interested').notNull().default('Pending'), appointmentAt: text('appointment_at'),
  installed: text('installed').notNull().default('No'), installedAt: text('installed_at'), estimatedRevenue: real('estimated_revenue'),
  noSaleReason: text('no_sale_reason'), description: text('description'), retentionUntil: text('retention_until'),
  updatedAt: text('updated_at').notNull(), createdBy: text('created_by').notNull(),
});
export const loginAttempts = sqliteTable('login_attempts', {
  key: text('key').primaryKey(), windowStart: integer('window_start').notNull(), attempts: integer('attempts').notNull().default(0),
});
export type Case = typeof cases.$inferSelect;
export const hubSettings = sqliteTable('hub_settings', {key:text('key').primaryKey(),value:text('value').notNull(),updatedAt:text('updated_at').notNull()});
export const historicalEdits = sqliteTable('historical_edits', {id:integer('id').primaryKey(),value:text('value').notNull(),updatedAt:text('updated_at').notNull()});
