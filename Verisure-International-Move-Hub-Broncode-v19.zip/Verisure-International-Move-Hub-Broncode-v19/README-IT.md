# Verisure International Move Hub — volledige broncode

Overdracht van online versie **19**, gepubliceerd op 7 oktober 2026.
Broncommit: `24beed8ce9261d318d789222e8a2b3ff1200af2f`.

## Begin hier

Dit pakket bevat de volledige applicatiecode: dashboard, login, adminportaal,
landpagina’s, API/backend, validatieregels, vertalingen, database-schema en
SQL-migraties. De nieuwste HTML-ingang is `/hub.html`; beheer is `/admin.html`
of `/admin`. Gebruikers openen straks uitsluitend de online URL in hun browser.
Zij hoeven niets te installeren. De onderstaande ontwikkeltools zijn voor IT
of een CI-buildomgeving.

| Map/bestand | Inhoud |
| --- | --- |
| `source/` | Broncode van de gepubliceerde versie, inclusief packagebestanden en lockfile |
| `source/app/` | Dashboard, login, admin, 18 landen en alle API-routes |
| `source/lib/move-cases.ts` | Casevalidatie, pilotindeling en timerberekening |
| `source/db/` en `source/drizzle/` | Databaseschema en SQL-migraties |
| `source/server/` | Instellingen, historische verwerking en historische bronimport |
| `hosting-cloudflare/` | Configuratie en conversiescript voor hosting op een eigen Cloudflare-account |
| `docs/` | Architectuur, API-overzicht, beheer en gegevensoverdracht |
| `RELEASE.json` | Versie en herkomst van deze export |
| `SHA256SUMS.txt` | SHA-256-vingerafdrukken van de meegeleverde bestanden |

De bronmap is een export uit Git, geen Git-checkout: interne tokens,
Git-credentials, geïnstalleerde dependencies en lokale cachebestanden ontbreken.
Een oude gegenereerde release-archive en TypeScript-buildcache zijn eveneens
weggelaten; dit zijn geen bronbestanden.

## Beheer overnemen

1. Plaats `source/` in een interne Git-repository.
2. Laat IT de hosting- en datalocatie kiezen. Dit is een React/Vinext-applicatie
   met een Cloudflare Workers-backend en D1-database; alleen een HTML-bestand op
   SharePoint, IIS, een statische host of een netwerkschijf is onvoldoende.
3. Gebruik voor een eigen Cloudflare-account de configuratie hieronder. Een
   gewone Node-server, Azure App Service of IIS vraagt een aparte backend- en
   database-adapter; die platforms zijn geen directe deployment van deze code.
4. Richt de database, runtime-secrets, hostingaccount en domein in onder een
   organisatieaccount. De ZIP draagt het bestaande hostingaccount of de huidige
   database niet automatisch over.
5. Lees `docs/GEGEVENSOVERDRACHT.md` voordat bestaande livegegevens worden verhuisd.

## Zelf hosten op Cloudflare Workers + D1

Deze route gebruikt hetzelfde dashboard en dezelfde backendcode. Het
conversiescript vervangt uitsluitend de ontwikkel-/hostingconfiguratie en scripts
in de uitgepakte kopie. Het verwijdert de Sites-buildintegratie uit die kopie;
het wijzigt niets aan de huidige online Hub. Applicatiebestanden blijven intact.

Benodigd in de IT-buildomgeving: Node.js >=22.13.0 en pnpm 11.25.0, plus toegang
 tot het gekozen Cloudflare-account. Gebruik de vastgelegde dependencyversies.

Voer vanaf de hoofdmap van dit pakket uit:

```sh
node hosting-cloudflare/configure.mjs
cd source
pnpm install --frozen-lockfile
pnpm exec wrangler login
pnpm exec wrangler d1 create verisure-move-hub
```

Vul in `source/wrangler.jsonc` de echte `database_id` uit het antwoord in. Zet
zonodig ook de Workernaam en database_name op de intern gekozen namen. De
configuratie bevat een gemarkeerde placeholder; die is geen bestaande database.

```sh
pnpm exec wrangler d1 migrations apply DB --remote --config wrangler.jsonc
pnpm build
pnpm exec wrangler deploy
pnpm exec wrangler secret put ACCESS_CODE --config wrangler.jsonc
pnpm exec wrangler secret put ADMIN_ACCESS_CODE --config wrangler.jsonc
pnpm exec wrangler secret put SESSION_SECRET --config wrangler.jsonc
```

Wrangler vraagt elke secret interactief; zet echte waarden nooit in broncode,
Git of een meegestuurde tekstfile. Gebruik aparte team- en admincodes. Gebruik
voor `SESSION_SECRET` een willekeurige waarde van minimaal 32 tekens. De eerste
publicatie is pas bruikbaar voor login nadat deze drie secrets bestaan. Koppel
via het Cloudflare-account het eigen domein aan de Worker en activeer HTTPS.

`pnpm build` gebruikt de Cloudflare Vite-plugin. Die genereert de
Wrangler-deployconfig; `wrangler deploy` detecteert de buildconfig. Gebruik voor
database- en secretbeheer expliciet `--config wrangler.jsonc`, zoals hierboven.

De oorspronkelijke `source/vite.config.ts`, package-scripts, werkruimtebeleid,
README en overige beheerconfiguratie blijven beschikbaar via het oorspronkelijke
pakket of worden door het conversiescript in `sites-original-config/` bewaard.
Pas de conversie eenmaal toe op een uitgepakte kopie. Maak daarna een eigen commit.

## Wat is al gecontroleerd?

De oorspronkelijke versie 19 is succesvol gebouwd en gepubliceerd. De export
is gekoppeld aan dezelfde commit. Er zijn voor deze overdracht geen tests
uitgevoerd en geen cases aangemaakt. De configuratie voor zelfstandig beheer is
nog niet op het IT-account gepubliceerd of functioneel getest; IT moet die
omgeving bij ingebruikname accepteren.

## Belangrijk voor de gegevens

Nieuwe live cases, instellingen, historische correcties en loginlimieten worden
opgeslagen in de bestaande D1-database. Deze ZIP bevat geen dump van die database.
Wel inbegrepen is het historische importbestand waarop de historische sectie is
gebaseerd; dit bevat bedrijfsgegevens en installatienummers. Behandel het pakket
als interne bedrijfsinformatie.

De originele frontend-HTML-export is als origineel bronbestand behouden. Gebruik
voor de volledige applicatie `/hub.html`, niet een los HTML-bestand op schijf.
Bij de Cloudflare-conversie wordt de oude statische export verwijderd zodat de
bestaande gelijknamige serverroute de volledige applicatie kan leveren.
